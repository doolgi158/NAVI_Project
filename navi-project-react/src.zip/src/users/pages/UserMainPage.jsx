import MainLayout from "../layout/MainLayout";

const UserMainPage = () => {
    return (
        <MainLayout>
            <div className="text-3xl">
                <div>Contents</div>
            </div>
        </MainLayout>
    );
}

export default UserMainPage;