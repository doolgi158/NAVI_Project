import MainLayout from "../layout/MainLayout";

const FlightRsvInputPage = () => {
    return(
        <MainLayout>
            <div>항공편 예약정보 입력 페이지</div>
        </MainLayout>
    )
}

export default FlightRsvInputPage;