import MainLayout from "../layout/MainLayout";

const FlightDetailPage = () => {
    return(
        <MainLayout>
            <div>항공편 상세 페이지</div>
        </MainLayout>
    )
}
export default FlightDetailPage;
