// src/common/ModalProvider.jsx
import { createContext, useContext, useState } from "react";
import LoginModal from "./LoginModal";
// 앞으로 SignupModal, ForgotModal 등 계속 import 예정

const ModalContext = createContext();
export const useModal = () => useContext(ModalContext);

export const ModalProvider = ({ children }) => {
  const [openModal, setOpenModal] = useState(null);

  const showModal = (name) => setOpenModal(name);
  const closeModal = () => setOpenModal(null);

  return (
    <ModalContext.Provider value={{ showModal, closeModal }}>
      {children}

      {/* 필요한 모달들 한 번에 정의 */}
      <LoginModal open={openModal === "login"} onClose={closeModal} />
      {/* <SignupModal open={openModal === "signup"} onClose={closeModal} /> */}
      {/* <ForgotModal open={openModal === "forgot"} onClose={closeModal} /> */}
    </ModalContext.Provider>
  );
};