package com.navi.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FindUserIdDTO {
    private String name;
    private String email;
}
