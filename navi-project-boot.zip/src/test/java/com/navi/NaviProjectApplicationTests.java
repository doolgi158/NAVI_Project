package com.navi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaviProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
