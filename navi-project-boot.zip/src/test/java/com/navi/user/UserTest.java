package com.navi.user;

import com.navi.user.enums.UserRole;
import com.navi.user.enums.UserState;
import com.navi.user.domain.User;
import com.navi.user.repository.UserRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.Random;

@SpringBootTest
public class UserTest {
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @PersistenceContext
    private EntityManager em;

    // 관리자 만들기
    @Test
    public void CreateAdmin(){
        User user = User.builder()
                .name("NAVI")
                .phone("01012341234")
                .birth("2025-08-29")
                .email("enfrlwlapdlf@gmail.com")
                .id("naviadmin")
                .pw(passwordEncoder.encode("skqlAdmin1234!"))
                .userState(UserState.NORMAL)
                .build();
        user.addRole(UserRole.ADMIN);
        userRepository.save(user);
    }

    // 사용자 만들기
    @Test
    public void Insertuser() {
        Random random = new Random();
        SecureRandom secureRandom = new SecureRandom();
        StringBuilder phone = new StringBuilder();
        StringBuilder personal = new StringBuilder();
        StringBuilder password = new StringBuilder();
        UserState[] values = UserState.values();

        for(int i = 0; i <= 1000; i++) {
            for (int j = 0; j < 8; j++) {
                phone.append(random.nextInt(10));
            }
            for (int j = 0; j < 13; j++) {
                personal.append(random.nextInt(10));
            }
            password.append("user").append(i).append("!");

            UserState state = values[random.nextInt(values.length)];
            int phonenum = 10000000 + random.nextInt(90000000);

            User user = User.builder()
                    .name("user" + i)
                    .phone("010" + phonenum)
                    .birth(phone.toString())
                    .email("user" + i + "@naver.com")
                    .id("navi" + i)
                    .pw(passwordEncoder.encode(password.toString()))
                    .userState(state)
                    .build();
            user.addRole(UserRole.USER);
            userRepository.save(user);
            phone.setLength(0);
            personal.setLength(0);
            password.setLength(0);
        }
    }

    @Test
    @Transactional
    public void insertRolesOnly() {
        for (int i = 0; i <= 1000; i++) {
            String role = (i == 0) ? "ADMIN" : "USER";
            em.createNativeQuery("INSERT INTO navi_user_roles (user_no, role) VALUES (?, ?)")
                    .setParameter(1, i)
                    .setParameter(2, role)
                    .executeUpdate();
        }
    }
}
