package com.navi.user.enums;

public enum SocialState {
    google, kakao, naver;
}
