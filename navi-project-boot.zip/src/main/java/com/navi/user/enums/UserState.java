package com.navi.user.enums;

public enum UserState {
    NORMAL, SLEEP, DELETE;
}