package com.navi.room.dto.request;

public class RoomRsvRequestDTO {
}
