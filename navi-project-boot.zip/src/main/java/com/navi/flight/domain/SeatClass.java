package com.navi.flight.domain;

public enum SeatClass {
    ECONOMY,   // 일반석
    PRESTIGE   // 프레스티지석
}
