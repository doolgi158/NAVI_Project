package com.navi.admin.travel.service;

import com.navi.admin.user.dto.AdminDashboardDTO;

import java.util.List;
import java.util.Map;

public interface AdminTravelDashboardService {
    AdminDashboardDTO.Travels getMonthlyTravelStats();

    List<Map<String, Object>> getTopTravelRank();
}
