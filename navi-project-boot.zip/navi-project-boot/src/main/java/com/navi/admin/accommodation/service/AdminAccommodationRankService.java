package com.navi.admin.accommodation.service;

import java.util.List;
import java.util.Map;

public interface AdminAccommodationRankService {
    List<Map<String, Object>> getTopAccommodationRank();
}
