package com.navi.admin.user.repository;

public interface AdminUserRepository {
}
