package com.navi.admin.analytics.service;

import java.util.Map;

public interface AdminUsageDashboardService {
    Map<String, Object> getUsageTrend();
}
