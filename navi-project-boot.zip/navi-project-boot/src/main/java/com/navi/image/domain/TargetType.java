package com.navi.image.domain;

public enum TargetType {
    USER, ROOM, ACC, TRAVEL, POST, ETC
}
