package com.navi.room.controller;

public class RoomController {
}
