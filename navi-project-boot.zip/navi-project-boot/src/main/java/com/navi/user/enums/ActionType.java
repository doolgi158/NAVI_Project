package com.navi.user.enums;

public enum ActionType {
    VIEW_TRAVEL,          // 여행지 조회
    VIEW_ACCOMMODATION,   // 숙소 조회
}
