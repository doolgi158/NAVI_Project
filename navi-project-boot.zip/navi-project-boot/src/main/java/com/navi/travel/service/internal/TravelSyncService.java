package com.navi.travel.service.internal;

public interface TravelSyncService {
    int saveApiData();

    void syncTravelData();
}
