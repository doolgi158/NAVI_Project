package com.navi.travel.service.internal;

import com.navi.travel.dto.TravelListResponseDTO;
import com.navi.travel.dto.TravelRequestDTO;

public interface TravelAdminService {
    void deleteTravel(Long travelId);

    TravelListResponseDTO saveTravel(TravelRequestDTO dto);
}
