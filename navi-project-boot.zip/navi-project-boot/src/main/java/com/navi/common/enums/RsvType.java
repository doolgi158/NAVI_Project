package com.navi.common.enums;

public enum RsvType {
    ACC,      // 숙소
    FLY,      // 항공
    DLV;     // 짐배송
}
